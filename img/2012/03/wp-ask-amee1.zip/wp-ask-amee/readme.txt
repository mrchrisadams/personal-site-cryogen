=== Ask AMEE ===
Contributors: chris_d_adams 
Tags: widgets
Requires at least: 3.0.2
Tested up to: 3.4
Stable tag: 0.1.0

Add the Ask AMEE widget on your blog, to let users make environmental calculations on your site

== Description ==


== TODO ==

* Create proper embeddable widget using the WP-widget class
* Add instructions on styling the widget
* Test the plugin on more than one site
* Add default styles

== Changelog == 

0.0.1 Had the idea, and created the simplest function possible to spit out an Ask AMEE box. 